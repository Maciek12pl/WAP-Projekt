package com.uep.wap.model;

import javax.persistence.*;

@Entity
@Table(name = "games")
public class Game {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "game_id")
    private long id;

    @Column(name = "result")
    private boolean result;

    @Column(name = "referee")
    private String referee;

    @Column(name = "player1")
    private String player1;

    @Column(name = "player2")
    private String player2;

    @ManyToOne
    @JoinColumn(name = "tournament_id")
    private Tournament tournament;

    @OneToOne(mappedBy = "game", cascade = CascadeType.ALL)
    private Board board;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }
}
