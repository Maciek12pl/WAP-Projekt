package com.uep.wap.model;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "organizers")
public class Organizer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "organizer_id")
    private long id;

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;

}
