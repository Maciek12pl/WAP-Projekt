package com.uep.wap.service;

public class OrganizerService {
}
