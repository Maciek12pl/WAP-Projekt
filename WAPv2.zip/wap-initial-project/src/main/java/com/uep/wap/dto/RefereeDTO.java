package com.uep.wap.dto;

public class RefereeDTO {
}
