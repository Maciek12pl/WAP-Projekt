package com.uep.wap.service;

public class GameService {
}
