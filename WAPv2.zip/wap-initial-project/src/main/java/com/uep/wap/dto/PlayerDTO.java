package com.uep.wap.dto;

public class PlayerDTO {
    private long elo_rating;

    public long getElo_rating() {
        return elo_rating;
    }

    public void setElo_rating(long elo_rating) {
        this.elo_rating = elo_rating;
    }
}
