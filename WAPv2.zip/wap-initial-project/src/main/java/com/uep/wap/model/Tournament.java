package com.uep.wap.model;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "tournaments")
public class Tournament {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tournament_id")
    private long id;

    @Column(name = "name")
    private String name;

    @Column(name = "date")
    private String date;

    @Column(name = "place")
    private String place;

    @Column(name = "game_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long game_id;

    @OneToMany(mappedBy = "tournament_id", cascade = CascadeType.ALL)
    private List<Game> game;

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "user_tournament",
                joinColumns = @JoinColumn(name = "tournament_id"),
                inverseJoinColumns = @JoinColumn(name = "user_id"))
    private List<User> users;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public long getGame_id() {
        return game_id;
    }

    public void setGame_id(long game_id) {
        this.game_id = game_id;
    }
}
